// Holds possible states for the current game
public enum State {
    INPROGRESS,
    WIN,
    DRAW;
}